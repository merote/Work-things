import Popup from 'reactjs-popup'
//import React from 'react';
import { connect } from 'react-redux'
import IconButton from '@material-ui/core/IconButton';
import CommentIcon from '@material-ui/icons/Comment';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Button from '@material-ui/core/Button';
import React, { useState } from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Switch from '@material-ui/core/Switch';

const ListDialog = (props, index) => {

  const [click, setClick] = useState(false);
  const [check, setCheck] = useState(false);
  const [nelio, setNelio] = useState(false);

  console.log(props, index)

  const neliot = [
    {
      value:'eka', 
      label:'10 - 40'
    },
    {
      value:'toka', 
      label:'40 - 100'
    },
    {
      value:'kolmas', 
      label:'100 -'
    }
  ]

  const handleClickOpen = () => {
    setClick(true)
  };

  const handleClose = () => {
    setClick(false)
  };

  const handleChange = () => {
    setCheck(!check)
  };

  const handleChange2 = name => event => {
    setNelio({[name]: event.target.value });
  };
  
    return (
      <div>
        <Button variant="outlined" color="primary" onClick={handleClickOpen}>
          Täytä tiedot
        </Button>
        <Dialog
          open={click}
          onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">{"Siivouspalvelu"}</DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
             Ilmoita tarkemmat tiedot palvelusta
            </DialogContentText>
            <TextField
          required
          id="standard-required"
          label="Osoite"
          margin="normal"
          /><div></div>
           <TextField
          required 
          id="outlined-select-currency"
          select
          label="Valitse"
          value={nelio}
          onChange={handleChange2('nelio')}
          helperText="Huoneiston koko neliöinä"
          margin="normal"
          variant="outlined"
        >
          {neliot.map(option => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField><div></div>
        <FormControlLabel
          control={
            <Switch
              checked={check}
              onChange={handleChange}
              value="kyllä"
            />
          }
          label="Rakennuksessa hissi"
        /><div></div>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
              Peruuta
            </Button>
            <Button onClick={handleClose} color="primary" autoFocus>
              Hyväksy
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  
}

export default ListDialog;

