export const editChecked1 = checked => ({
    type: 'EDIT_CHECKED1',
    checked
})

export const editChecked2 = checked => ({
    type: 'EDIT_CHECKED2',
    checked
})


