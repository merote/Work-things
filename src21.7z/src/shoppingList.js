import ListItemText from '@material-ui/core/ListItemText';
import Checkbox from '@material-ui/core/Checkbox';
import { connect } from 'react-redux'
import { checkList1, checkList2 } from './actionCreators'
import Grid from '@material-ui/core/Grid';
import DialogCustomer  from './dialogCustomer.js'
import { useState } from 'react';
import Button from '@material-ui/core/Button';
import React from 'react';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemSecondaryAction from '@material-ui/core/ListItemSecondaryAction';


/*const MainService = ["Mini", "Keski", "Laaja", "Räätälöity"]
const Service = ["siivous", "tiskaus", "imurointi", "syöttäminen", "strippaaminen"]
const Service_lists = [[0,0,1,0,0],[1,0,1,0,1],[1,1,1,1,1]]
const checked2_init = [0,0,0,0,0]
const mixed_index = MainService.length-1
*/

const mapStateToProps = (state) => ({
  list1: state.adminReducer,
  list2: state.adminReducer2,
  customer: state.customerReducer
});

const mapDispatchToProps = {
  checkList1,
  checkList2
}


const ShoppingList = (props) => {

    return (
        <Grid container spacing={24} justify='center' >  

        <Grid item xs={3}>
        <List >
            <ListItem key={1} dense divider>
              <ListItemText primary={"OSTOKSET / TIEDOT"} />
              <ListItemSecondaryAction>
              <b>Hinta</b>
            </ListItemSecondaryAction>  
            </ListItem>          
            <ListItem key={2} >
              <ListItemText 
              primary = {"Palvelutaso: "} 
              secondary = { props.list1[props.customer.list1].name} 
              />
            </ListItem>   
            {props.customer.list2.map((a,i) => (
               <ListItem key={i} divider>
                 <ListItemText 
                 secondary = {props.list2[a].name}
                 primary= {"Palvelu: "} />
            </ListItem>  
                

            ))}
     

        </List>
        </Grid>
    
      </Grid>
      );  
  


    

}

export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(ShoppingList);
  