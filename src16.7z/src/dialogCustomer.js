import { connect } from 'react-redux'
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Button from '@material-ui/core/Button';
import React, { useState } from 'react';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import {deleteData} from './actionCreators'
import Checkbox from '@material-ui/core/Checkbox';
import FormGroup from '@material-ui/core/FormGroup';
import FormLabel from '@material-ui/core/FormLabel';

const mapStateToProps = (state) => ({
   state2: state.adminReducer2,
});

const mapDispatchToProps = {
  deleteData
}

const showText = (data) => {
  return (
    <TextField
      required = {data.required}
      label = {data.name}
      margin = "normal"
      variant = "outlined" 
      type = {data.input_type}
      />)
}

const showCheckbox = (data) => {
  return (
    <FormLabel>
      <b>{data.name}</b>
      <b>{data.required === true ? " *" : ""}</b>
      <FormGroup row>
        {data.choises.map((a,i) => (
          <FormControlLabel key={i}
            control={
              <Checkbox
                checked={false}
              />}
            label={a.name}
          />
        ))}
      </FormGroup>
    </FormLabel>  
  )
}

const DialogCustomer = (props) => {

  const [click, setClick] = useState(false);
  //const [check, setCheck] = useState(false);

  const handleClickOpen = () => {
    setClick(true)
  };

  const handleClose = () => {
    setClick(false)
  };

    return (
      <div>
        <Button variant="outlined" color="primary" onClick={handleClickOpen}>
          Täytä tiedot
        </Button>
        <Dialog
          open={click}
          onClose={handleClose}
          aria-labelledby="dialog-title"
        >
          <DialogTitle id="dialog-title">{props.state2[props.index].name}</DialogTitle>
          <DialogContent>
 
            <List>
            {props.state2[props.index].data.map((a,i) => (
                 <ListItem key={i} role={undefined} dense divider >          
                {a.type === "text" ? showText(a) : showCheckbox(a)}
                </ListItem>
             ))} 
            </List>
          </DialogContent>
          <DialogActions>
            <Button variant="outlined" onClick={handleClose} color="primary">
              Sulje
            </Button>
           </DialogActions>
        </Dialog>
      </div>
    );
  
}

export default connect(
  mapStateToProps, mapDispatchToProps)(DialogCustomer);

