import axios from 'axios'

const getList1 = async () => {
    const response = await axios.get('/api/palvelutasot')
    return response.data
}

const getList2 = async () => {
    const response = await axios.get('/api/palvelut')
    return response.data
}  


export const Lists_Load = () => {

    const data1 = getList1()
    const tasot_redux = []
    data1.then(data => {
        data.forEach((a,i) => {
            tasot_redux[i] = {
                name: a.kuvaus,
                id: a.id,
                list2_id: a.palvelut.length > 0 ? a.palvelut.map(b => b.id) : []
            }
        })
    })

    const data2 = getList2()
    const palvelut_redux = []
    data2.then(data => {
        data.forEach((a,i) => {
            palvelut_redux[i] = {
                name: a.kuvaus,
                id: a.id,
                data: []
            }
        })
    })

    const data = [tasot_redux, palvelut_redux]
    return data

//    const promise = axios.get('/api/palvelutasot')    
//    const test = promise.then(response => {
    
/*        tasot.forEach((a,i) => {
            tasot_redux[i] = {
                name: a.kuvaus,
                id: a.id,
                list2_id: a.palvelut.length > 0 ? a.palvelut.map(b => b.id-1) : []
            }
        })   
*/


    

    
    //console.log(test)
/*
        console.log('TEST4')
        const promise = axios.get('/api/palvelut')    
        promise.then(response => {
            const palvelut = response.data
            console.log(palvelut)
            const palvelut_redux = []
            palvelut.forEach((a,i) => {
                palvelut_redux[i] = {
                    name: a.palvelunNimi,
                    id: i,
                    data: []
                }
            })        
        return palvelut_redux
    })       
 */   
 //   console.log(tasot_redux)
  
    //return (list_number === 1 ? tasot_redux : palvelut_redux)
    
  /*  const tasot = [
        {   id : 1,    
            "kuvaus": "Räätälöity",
            "palvelut": []
        },
        {   id : 2,
            "kuvaus": "Mini",
            "palvelut": []
        },
        {   id : 3,
            "kuvaus": "Keski",
            "palvelut": [
                {kuvaus: "test", id: 2},
                { kuvaus: "dafafafa", id: 4}
            ]
        },
        {   id : 4,
            "kuvaus": "Laaja",
            "palvelut": []
        }
    ]

    const palvelut = [
        {   id: 1,
           "palvelunNimi": "Eka",
            "kentat": []
        },
        {   id: 2,
            "palvelunNimi": "test",
            "kentat": []
        },
        {   id: 3,
            "palvelunNimi": "Toka",
            "kentat": []
        },
        {   id: 4,
            "palvelunNimi": "dafafafa",
            "kentat": []
        }
    ]*/



    //return   [tasot_redux, palvelut_redux]

}

//export default (Lists_Load);