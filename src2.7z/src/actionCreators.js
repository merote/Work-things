export const editChecked1 = checked => ({
    type: 'EDIT_CHECKED1',
    checked
})
export const editChecked2 = checked => ({
    type: 'EDIT_CHECKED2',
    checked
})
export const editList1 = (id, name) => ({
    type: 'EDIT_LIST1',
    name,
    id
})
export const addList1 = name => ({
    type: 'ADD_LIST1',
    name
})
export const deleteList1 = id => ({
    type: 'DELETE_LIST1',
    id
})
export const addList2 = name => ({
    type: 'ADD_LIST2',
    name
})
export const editList2 = (id, name) => ({
    type: 'EDIT_LIST2',
    name,
    id
})
export const deleteList2 = id => ({
    type: 'DELETE_LIST2',
    id
})