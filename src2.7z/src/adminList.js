//import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemSecondaryAction from '@material-ui/core/ListItemSecondaryAction';
import ListItemText from '@material-ui/core/ListItemText';
import Checkbox from '@material-ui/core/Checkbox';
import IconButton from '@material-ui/core/IconButton';
import CommentIcon from '@material-ui/icons/Comment';
import Icon from '@material-ui/core/Icon';
//import Paper from '@material-ui/core/Paper';
//import { Table } from '@material-ui/core';
import store from './index.css';
import { Column, Row } from 'simple-flexbox';
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import Button from '@material-ui/core/Button';
//import Popup from "reactjs-popup";
import axios from 'axios'
import { resolveCname } from 'dns';
import { connect } from 'react-redux'
import {editChecked1, editChecked2 } from './actionCreators'
import { throws } from 'assert';
import Popup from 'reactjs-popup'
import ListPopup from './Popup'
import Grid from '@material-ui/core/Grid';
import ListDialog from './Popup.js'
import {editList1, addList1, deleteList1,addList2,deleteList2} from './actionCreators'
import Input from '@material-ui/core/Input';
import TextField from '@material-ui/core/TextField';
import DeleteIcon from '@material-ui/icons/Delete';
import React, { useState } from 'react';
import AdminList2 from './adminList2'



const mapStateToProps = (state) => ({
    state: state.adminReducer,

});
  
const mapDispatchToProps = {
  editList1,
  addList1,
  deleteList1,
}



const AdminList = (props) => {
 
  console.log(props)

    const [input1, setList1] = useState("");
    const [check, setCheck] = useState(1);

    const handleAdd1 = (text) => () => { 
        setList1("")
        props.addList1(text)
      }
      
    const handleChange = (event) => {
      setList1(event.target.value)
    }

    const handleCheck = (index) => () => {
      setCheck(index)
    }

    const handleDelete1 = (index) => () => {
      setCheck()
      const delete_id = props.state[index].id
      return props.deleteList1(delete_id)
    }


    return (
    
      
      <Grid container spacing={24}>
        <Grid container item xs={12} justify='center' >
          <Button variant="contained" size="large">Tallenna uusi yhdistelmä</Button>
        </Grid>
        <Grid item xs={3}>
          <List >
            <ListItem role={undefined} dense divider >
              <TextField
                label="Uusi palvelutaso"
                margin="normal"
                variant="outlined"
                value={input1}
                onChange={handleChange}
              />
              <ListItemSecondaryAction>
                <Button variant="contained" onClick={handleAdd1(input1)}>Lisää</Button>                 
              </ListItemSecondaryAction>
            </ListItem>
            {props.state.map((value, index) => (
              <ListItem key={index} role={undefined} dense divider >
                <IconButton aria-label="Delete" disabled = {index===0} onClick={handleDelete1(index)} >
                  <DeleteIcon />
                </IconButton>

                <Checkbox
                  checked={index === check}
                  onChange={handleCheck(index)}
                  disableRipple
                />
                <ListItemText primary={value.name} />
              </ListItem>
            ))}
          </List>
        </Grid>
        <Grid item xs={4}>
          <AdminList2 checked1 = {check}/>  
        </Grid>
      </Grid>
  );
}



export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(AdminList);
  