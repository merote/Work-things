import axios from 'axios'


export const Lists_Load = () => {

    const tasot = [
        {   id : 1,    
            "kuvaus": "Räätälöity",
            "palvelut": []
        },
        {   id : 2,
            "kuvaus": "Mini",
            "palvelut": []
        },
        {   id : 3,
            "kuvaus": "Keski",
            "palvelut": [
                {kuvaus: "test", id: 2},
                { kuvaus: "dafafafa", id: 4}
            ]
        },
        {   id : 4,
            "kuvaus": "Laaja",
            "palvelut": []
        }
    ]

    const palvelut = [
        {   id: 1,
           "palvelunNimi": "Eka",
            "kentat": []
        },
        {   id: 2,
            "palvelunNimi": "test",
            "kentat": []
        },
        {   id: 3,
            "palvelunNimi": "Toka",
            "kentat": []
        },
        {   id: 4,
            "palvelunNimi": "dafafafa",
            "kentat": []
        }
    ]

    const tasot_redux =[]
    tasot.forEach((a,i) => {
        tasot_redux[i] = {
            name: a.kuvaus,
            id: a.id,
            list2_id: a.palvelut.length > 0 ? a.palvelut.map(b => b.id-1) : []
        }
    })

    const palvelut_redux = []
    palvelut.forEach((a,i) => {
        palvelut_redux[i] = {
            name: a.palvelunNimi,
            id: i,
            data: []
        }
    })

    return   [tasot_redux, palvelut_redux]
}

