import * as types from '../constants/ActionTypes'

export const editChecked1 = checked => ({ type: types.EDIT_CHECKED1, checked })
export const editChecked2 = checked => ({ type: types.EDIT_CHECKED2, checked })