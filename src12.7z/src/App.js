import React, { useState } from 'react'
import CheckboxList from './CheckboxList';
import AdminList from './adminList';
import Button from '@material-ui/core/Button';
import Extra from './extra.js'

const buttons = ["Asiakas", "Admin", "Extra"]


const App = (props) => {
  const store = props.store
  
  const [page, setPage] = useState(0)
  
  return (
    <div>
      {buttons.map((name,i) => (
        <Button key ={i} variant="outlined" color="primary"
          onClick={() => setPage(i)}
        >
        {name}  
        </Button>
      ))
    }
    <div></div>
      {page === 0 
      ? <CheckboxList store={store}/> 
      :page === 1  
      ? <AdminList store={store}/>
      : <Extra />}
    </div>
  )
}

export default App

/*  return (
    <div>
        <Button variant="outlined" color="primary" 
          onClick={page === 1 ? () => setPage(2)
          : () =>  setPage(1)}>
          Vaihda näkymä
        </Button>
  
    <div></div>
      {page === 1 
      ? <CheckboxList store={store}/> 
      : <AdminList store={store}/>}
    </div>
  )
}*/