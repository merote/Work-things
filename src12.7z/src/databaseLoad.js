import axios from 'axios'


export const List1_Load = () => {

    const tasot = [
        {
            kuvaus: "Räätälöity",
        },
        {
            kuvaus: "Laaja",
        },
        {
            kuvaus: "Mini",
        },
        {
            kuvaus: "Keski",
        }
    ]

    const linkit = [
    {    
        palvelutaso_id: 4,
        palvelu_id: 1
    },
    {
        palvelutaso_id: 4,
        palvelu_id: 3
    },
    {
        palvelutaso_id: 4,
        palvelu_id: 4
    },
    {    palvelutaso_id: 3,
        palvelu_id: 2
    }
    ]
    
    const temp_id2 = []
    tasot.forEach(() => temp_id2.push([]))
    
    linkit.forEach(a => {
        temp_id2[a.palvelutaso_id-1].push(a.palvelu_id-1)
    })
    
    const tasot_redux =[]
    tasot.forEach((a,i) => {
        tasot_redux[i] = {
            name: a.kuvaus,
            id: i,
            list2_id: temp_id2[i]
        }
    })
    return tasot_redux
}

export const List2_Load = () => {

    const palvelut = [
        {
            "palvelunNimi": "Eka",
            "kentat": []
        },
        {
            "palvelunNimi": "Kolmas",
            "kentat": []
        },
        {
            "palvelunNimi": "Toka",
            "kentat": []
        },
        {
            "palvelunNimi": "Neljäs",
            "kentat": []
        }
    ]

    const palvelut_redux = []

    palvelut.forEach((a,i) => {
        palvelut_redux[i] = {
            name: a.palvelunNimi,
            id: i,
            data: []
        }
    })
    

    return   palvelut_redux
}

