import React, { useState } from 'react'
import CheckboxList from './CheckboxList';
import AdminList from './adminList';
import Button from '@material-ui/core/Button';



const App = (props) => {
  const store = props.store
  
  const [page, setPage] = useState(1)

  return (
    <div>
        <Button variant="outlined" color="primary" 
          onClick={page === 1 ? () => setPage(2)
          : () =>  setPage(1)}>
          Vaihda näkymä
        </Button>
  
    <div></div>
      {page === 1 
      ? <CheckboxList store={store}/> 
      : <AdminList store={store}/>}
    </div>
  )
}

export default App